<html>
	<head>
		<title>
			MENÚ PRINCIPAL 
		</title>
	</head>
	<body>
		<h2> MENÚ PRINCIPAL DE L'APLICACIÓ D'ACCÉS</h2>
		<h3> <b>Fet per: Adrián Cano</b> </h3>
		<a href="http://zend-adcapo.fjeclot.net/zendldap/mostrar.php">Visualitzar usuaris</a><br>
		<a href="http://zend-adcapo.fjeclot.net/zendldap//insertar.php">Afegir usuaris</a><br>
		<a href="http://zend-adcapo.fjeclot.net/zendldap//modificar.php">Modificar usuaris</a><br>
		<a href="http://zend-adcapo.fjeclot.net/zendldap//eliminar.php">Esborrar usuaris</a><br>
		
	</body>
</html>
